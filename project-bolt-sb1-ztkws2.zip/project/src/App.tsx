import React, { useState } from 'react';
import { Share2 } from 'lucide-react';
import LinkCard from './components/LinkCard';
import ShareLinkForm from './components/ShareLinkForm';

interface Link {
  id: string;
  title: string;
  url: string;
  description: string;
  author: string;
  timestamp: Date;
  votes: number;
  comments: Array<{
    id: string;
    text: string;
    author: string;
    timestamp: Date;
  }>;
}

const initialLinks: Link[] = [
  {
    id: '1',
    title: 'React Documentation',
    url: 'https://react.dev',
    description: 'Official React documentation with guides and API reference',
    author: 'React Team',
    timestamp: new Date('2024-03-10'),
    votes: 42,
    comments: [
      {
        id: 'c1',
        text: 'Great resource for learning React!',
        author: 'WebDev',
        timestamp: new Date('2024-03-11'),
      },
    ],
  },
  {
    id: '2',
    title: 'Tailwind CSS',
    url: 'https://tailwindcss.com',
    description: 'A utility-first CSS framework for rapid UI development',
    author: 'CSS Enthusiast',
    timestamp: new Date('2024-03-09'),
    votes: 38,
    comments: [],
  },
];

function App() {
  const [links, setLinks] = useState<Link[]>(initialLinks);

  const handleShareLink = (newLink: { title: string; url: string; description: string }) => {
    const link: Link = {
      id: Date.now().toString(),
      ...newLink,
      author: 'Anonymous',
      timestamp: new Date(),
      votes: 0,
      comments: [],
    };

    setLinks(prev => [link, ...prev]);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-2">
            <Share2 className="text-blue-600" size={32} />
            <h1 className="text-3xl font-bold text-gray-900">ShareLinks</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <ShareLinkForm onSubmit={handleShareLink} />

        <div className="space-y-6">
          {links.map((link) => (
            <LinkCard
              key={link.id}
              title={link.title}
              url={link.url}
              description={link.description}
              author={link.author}
              timestamp={link.timestamp}
              initialVotes={link.votes}
              initialComments={link.comments}
            />
          ))}
        </div>
      </main>

      <footer className="bg-white border-t">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <p className="text-center text-gray-600">
            ShareLinks - Share and discover interesting links
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;