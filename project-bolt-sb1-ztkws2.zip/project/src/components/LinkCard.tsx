import React, { useState } from 'react';
import { ThumbsUp, ThumbsDown, MessageCircle, ExternalLink } from 'lucide-react';

interface Comment {
  id: string;
  text: string;
  author: string;
  timestamp: Date;
}

interface LinkCardProps {
  title: string;
  url: string;
  description: string;
  author: string;
  timestamp: Date;
  initialVotes: number;
  initialComments: Comment[];
}

export default function LinkCard({
  title,
  url,
  description,
  author,
  timestamp,
  initialVotes,
  initialComments,
}: LinkCardProps) {
  const [votes, setVotes] = useState(initialVotes);
  const [comments, setComments] = useState(initialComments);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');

  const handleVote = (increment: boolean) => {
    setVotes(prev => increment ? prev + 1 : prev - 1);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      text: newComment,
      author: 'Anonymous',
      timestamp: new Date(),
    };

    setComments(prev => [...prev, comment]);
    setNewComment('');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-4 transition-all hover:shadow-xl">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-gray-800 hover:text-blue-600">
              {title}
            </h2>
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-blue-600"
            >
              <ExternalLink size={16} />
            </a>
          </div>
          <p className="text-gray-600 mt-2">{description}</p>
          <div className="text-sm text-gray-500 mt-2">
            Shared by {author} • {new Date(timestamp).toLocaleDateString()}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-6 mt-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleVote(true)}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ThumbsUp size={18} className="text-gray-600" />
          </button>
          <span className="text-gray-600 font-medium">{votes}</span>
          <button
            onClick={() => handleVote(false)}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ThumbsDown size={18} className="text-gray-600" />
          </button>
        </div>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-2 text-gray-600 hover:text-blue-600"
        >
          <MessageCircle size={18} />
          <span>{comments.length} comments</span>
        </button>
      </div>

      {showComments && (
        <div className="mt-4">
          <form onSubmit={handleAddComment} className="mb-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Post
              </button>
            </div>
          </form>

          <div className="space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-medium text-gray-800">{comment.author}</span>
                  <span className="text-sm text-gray-500">
                    {new Date(comment.timestamp).toLocaleDateString()}
                  </span>
                </div>
                <p className="mt-2 text-gray-600">{comment.text}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}